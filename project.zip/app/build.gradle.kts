plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.hilal.galaxycal"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.hilal.galaxycal"
        minSdk = 26
        targetSdk = 34
        versionCode = 10
        versionName = "2.8"
    }

    // مفتاح توقيع ثابت عشان التحديثات تنزل فوق النسخة القديمة بدون حذفها
    signingConfigs {
        getByName("debug") {
            storeFile = file("../debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
