package com.hilal.galaxycal

import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import kotlin.math.*

data class PrayerTimes(
    val fajr: Double, val sunrise: Double, val dhuhr: Double,
    val asr: Double, val maghrib: Double, val isha: Double
)

// حساب أوقات الصلاة (طريقة أم القرى: زاوية الفجر 18.5°، العشاء = المغرب + 90 دقيقة)
object Prayer {

    fun compute(date: LocalDate, lat: Double, lng: Double, tz: Double): PrayerTimes {
        val jd = julianDate(date.year, date.monthValue, date.dayOfMonth) - lng / (15.0 * 24.0)
        val eqt = eqTime(jd)
        val decl = sunDeclination(jd)

        fun timeFor(angle: Double, ccw: Boolean): Double {
            val t = (1.0 / 15.0) * acosDeg(
                (-sinDeg(angle) - sinDeg(decl) * sinDeg(lat)) / (cosDeg(decl) * cosDeg(lat))
            )
            val noon = 12.0 + eqt / 60.0
            return noon + (if (ccw) -t else t)
        }

        fun fix(h: Double): Double {
            var v = h - tz + lng / 15.0
            while (v < 0) v += 24
            while (v >= 24) v -= 24
            return v
        }

        val noon = 12.0 + eqt / 60.0
        val fajr = timeFor(18.5, true)
        val sunrise = timeFor(0.833, true)
        val asrAngle = -atanDeg(1.0 / (1.0 + tanDeg(abs(lat - decl))))
        val asr = timeFor(asrAngle, false)
        val maghrib = timeFor(0.833, false)
        val isha = maghrib + 90.0 / 60.0

        return PrayerTimes(fix(fajr), fix(sunrise), fix(noon), fix(asr), fix(maghrib), fix(isha))
    }

    fun hhmm(t: Double): String {
        var h = floor(t).toInt(); var m = round((t - h) * 60).toInt()
        if (m == 60) { m = 0; h += 1 }
        h = ((h % 24) + 24) % 24
        return String.format("%02d:%02d", h, m)
    }

    // صيغة 12 ساعة مع ص/م
    fun hhmm12(t: Double): String {
        var h = floor(t).toInt(); var m = round((t - h) * 60).toInt()
        if (m == 60) { m = 0; h += 1 }
        h = ((h % 24) + 24) % 24
        val suffix = if (h < 12) "ص" else "م"
        var h12 = h % 12
        if (h12 == 0) h12 = 12
        return String.format("%d:%02d %s", h12, m, suffix)
    }

    // الوقت الحالي وأقرب صلاة قادمة (لدقائق حتى الأذان)
    fun nextPrayer(now: ZonedDateTime, lat: Double, lng: Double, tz: Double): Pair<String, Long> {
        val names = listOf("الفجر" to true, "الشروق" to false, "الظهر" to true, "العصر" to true, "المغرب" to true, "العشاء" to true)
        val nowH = now.hour + now.minute / 60.0
        var t = compute(now.toLocalDate(), lat, lng, tz)
        var list = listOf(t.fajr, t.sunrise, t.dhuhr, t.asr, t.maghrib, t.isha)
        for (i in list.indices) {
            if (list[i] > nowH) {
                val mins = ((list[i] - nowH) * 60).toLong()
                return names[i].first to mins
            }
        }
        // بعد العشاء: نرجع فجر الغد
        val tmr = compute(now.toLocalDate().plusDays(1), lat, lng, tz)
        val mins = ((24 - nowH + tmr.fajr) * 60).toLong()
        return "الفجر" to mins
    }

    private fun julianDate(y: Int, m: Int, d: Int): Double {
        var year = y; var month = m
        if (month <= 2) { year -= 1; month += 12 }
        val a = floor(year / 100.0)
        val b = 2 - a + floor(a / 4.0)
        return floor(365.25 * (year + 4716)) + floor(30.6001 * (month + 1)) + d + b - 1524.5
    }

    private fun sunDeclination(jd: Double): Double {
        val g = fixAngle(357.529 + 0.98560028 * (jd - 2451545.0))
        val q = fixAngle(280.459 + 0.98564736 * (jd - 2451545.0))
        val l = fixAngle(q + 1.915 * sinDeg(g) + 0.020 * sinDeg(2 * g))
        val e = 23.439 - 0.00000036 * (jd - 2451545.0)
        return asinDeg(sinDeg(e) * sinDeg(l))
    }

    private fun eqTime(jd: Double): Double {
        val g = fixAngle(357.529 + 0.98560028 * (jd - 2451545.0))
        val q = fixAngle(280.459 + 0.98564736 * (jd - 2451545.0))
        val l = fixAngle(q + 1.915 * sinDeg(g) + 0.020 * sinDeg(2 * g))
        val e = 23.439 - 0.00000036 * (jd - 2451545.0)
        var ra = atan2Deg(cosDeg(e) * sinDeg(l), cosDeg(l)) / 15.0
        ra = fixHour(ra)
        return (q / 15.0 - ra) * 60.0
    }

    private fun fixAngle(a: Double) = ((a % 360.0) + 360.0) % 360.0
    private fun fixHour(h: Double) = ((h % 24.0) + 24.0) % 24.0
    private fun sinDeg(d: Double) = sin(d * PI / 180.0)
    private fun cosDeg(d: Double) = cos(d * PI / 180.0)
    private fun tanDeg(d: Double) = tan(d * PI / 180.0)
    private fun asinDeg(x: Double) = asin(x.coerceIn(-1.0, 1.0)) * 180.0 / PI
    private fun acosDeg(x: Double) = acos(x.coerceIn(-1.0, 1.0)) * 180.0 / PI
    private fun atanDeg(x: Double) = atan(x) * 180.0 / PI
    private fun atan2Deg(y: Double, x: Double) = atan2(y, x) * 180.0 / PI
}
