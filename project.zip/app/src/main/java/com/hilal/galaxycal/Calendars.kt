package com.hilal.galaxycal

import java.time.LocalDate
import java.time.chrono.HijrahDate
import java.time.temporal.ChronoField

data class Hijri(val year: Int, val month: Int, val day: Int)

object Cal {
    const val SALARY_DAY = 27
    const val CITIZEN_DAY = 10
    val hijriMonths = arrayOf(
        "محرم", "صفر", "ربيع الأول", "ربيع الآخر", "جمادى الأولى", "جمادى الآخرة",
        "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة"
    )
    val gregMonths = arrayOf(
        "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
        "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"
    )
    // الفهرس 0 = الأحد
    val weekdays = arrayOf("الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت")
    val weekdaysShort = arrayOf("أحد", "اثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة", "سبت")

    fun toHijri(d: LocalDate): Hijri {
        return try {
            val h = HijrahDate.from(d)
            Hijri(h.get(ChronoField.YEAR), h.get(ChronoField.MONTH_OF_YEAR), h.get(ChronoField.DAY_OF_MONTH))
        } catch (e: Exception) {
            fallback(d)
        }
    }

    // حساب تقريبي احتياطي إذا ما اشتغل تقويم أم القرى في الجهاز
    private fun fallback(d: LocalDate): Hijri {
        val jd = d.toEpochDay() + 2440588L
        var l = jd - 1948440L + 10632L
        val n = (l - 1) / 10631L
        l = l - 10631L * n + 354L
        val j = ((10985L - l) / 5316L) * ((50L * l) / 17719L) + (l / 5670L) * ((43L * l) / 15238L)
        l = l - ((30L - j) / 15L) * ((17719L * j) / 50L) - (j / 16L) * ((15238L * j) / 43L) + 29L
        val m = (24L * l) / 709L
        val day = l - (709L * m) / 24L
        val y = 30L * n + j - 30L
        return Hijri(y.toInt(), m.toInt(), day.toInt())
    }

    fun occasions(d: LocalDate): List<String> {
        val out = ArrayList<String>()
        val h = toHijri(d)
        if (h.month == 1 && h.day == 1) out.add("رأس السنة الهجرية")
        if (h.month == 1 && h.day == 10) out.add("يوم عاشوراء")
        if (h.month == 9 && h.day == 1) out.add("أول أيام رمضان")
        if (h.month == 10 && h.day == 1) out.add("عيد الفطر")
        if (h.month == 12 && h.day == 9) out.add("يوم عرفة")
        if (h.month == 12 && h.day == 10) out.add("عيد الأضحى")
        if (d.monthValue == 2 && d.dayOfMonth == 22) out.add("يوم التأسيس")
        if (d.monthValue == 3 && d.dayOfMonth == 11) out.add("يوم العلم")
        if (d.monthValue == 9 && d.dayOfMonth == 23) out.add("اليوم الوطني السعودي")
        return out
    }
}

data class UpItem(val icon: String, val title: String, val date: LocalDate)
data class UpRow(val icon: String, val title: String, val rel: String)

object Up {
    fun toArabicDigits(s: String): String {
        val w = "٠١٢٣٤٥٦٧٨٩"
        val sb = StringBuilder()
        for (c in s) sb.append(if (c.isDigit()) w[c - '0'] else c)
        return sb.toString()
    }

    private fun nextMonthly(day: Int, from: LocalDate): LocalDate {
        var d = from.withDayOfMonth(minOf(day, from.lengthOfMonth()))
        if (d.isBefore(from)) {
            val nm = from.plusMonths(1)
            d = nm.withDayOfMonth(minOf(day, nm.lengthOfMonth()))
        }
        return d
    }

    fun relLabel(from: LocalDate, to: LocalDate): String {
        val diff = java.time.temporal.ChronoUnit.DAYS.between(from, to)
        val wk = Cal.weekdays[to.dayOfWeek.value % 7]
        val phrase = when {
            diff <= 0L -> "اليوم"
            diff == 1L -> "غدًا"
            diff < 11L -> "بعد ${diff} أيام"
            diff < 30L -> "بعد ${diff} يوم"
            else -> {
                val months = diff / 30; val rem = diff % 30
                val mTxt = if (months == 1L) "شهر واحد" else "$months أشهر"
                if (rem == 0L) "بعد $mTxt" else "بعد $mTxt و$rem يوم"
            }
        }
        return toArabicDigits("$wk $phrase")
    }

    // التقويم الدراسي 1448 (وزارة التعليم) — نفس تواريخ نسخة الويب
    private val schoolEvents = listOf(
        Triple("🎒", "بداية العام الدراسي", LocalDate.of(2026, 8, 23)),
        Triple("🏖", "إجازة الخريف", LocalDate.of(2026, 11, 20)),
        Triple("🏖", "إجازة منتصف العام", LocalDate.of(2027, 1, 8)),
        Triple("🎒", "بداية الفصل الثاني", LocalDate.of(2027, 1, 17)),
        Triple("🏖", "إجازة يوم التأسيس", LocalDate.of(2027, 2, 19)),
        Triple("🏖", "إجازة عيد الفطر", LocalDate.of(2027, 2, 26)),
        Triple("🏖", "إجازة عيد الأضحى", LocalDate.of(2027, 5, 7)),
        Triple("🏖", "بداية إجازة نهاية العام", LocalDate.of(2027, 6, 24))
    )

    private fun nextSchoolEvent(today: LocalDate): UpItem? =
        schoolEvents.firstOrNull { !it.third.isBefore(today) }?.let { UpItem(it.first, it.second, it.third) }

    fun list(today: LocalDate, appts: List<UpItem> = emptyList()): List<UpRow> {
        val items = ArrayList<UpItem>()
        items.add(UpItem("💰", "الرواتب الحكومية", nextMonthly(Cal.SALARY_DAY, today)))
        items.add(UpItem("💵", "حساب المواطن", nextMonthly(Cal.CITIZEN_DAY, today)))
        nextSchoolEvent(today)?.let { items.add(it) }
        items.addAll(appts.filter { !it.date.isBefore(today) })

        return items.sortedBy { it.date }.take(5).map { UpRow(it.icon, it.title, relLabel(today, it.date)) }
    }
}
