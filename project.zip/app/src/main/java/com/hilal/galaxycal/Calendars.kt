package com.hilal.galaxycal

import java.time.LocalDate
import java.time.chrono.HijrahDate
import java.time.temporal.ChronoField

data class Hijri(val year: Int, val month: Int, val day: Int)

object Cal {
    const val SALARY_DAY = 27
    const val CITIZEN_DAY = 10
    val hijriMonths = arrayOf(
        "محرم", "صفر", "ربيع الأول", "ربيع الآخر", "جمادى الأولى", "جمادى الآخرة",
        "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة"
    )
    val gregMonths = arrayOf(
        "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
        "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"
    )
    // الفهرس 0 = الأحد
    val weekdays = arrayOf("الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت")
    val weekdaysShort = arrayOf("أحد", "اثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة", "سبت")

    fun toHijri(d: LocalDate): Hijri {
        return try {
            val h = HijrahDate.from(d)
            Hijri(h.get(ChronoField.YEAR), h.get(ChronoField.MONTH_OF_YEAR), h.get(ChronoField.DAY_OF_MONTH))
        } catch (e: Exception) {
            fallback(d)
        }
    }

    // حساب تقريبي احتياطي إذا ما اشتغل تقويم أم القرى في الجهاز
    private fun fallback(d: LocalDate): Hijri {
        val jd = d.toEpochDay() + 2440588L
        var l = jd - 1948440L + 10632L
        val n = (l - 1) / 10631L
        l = l - 10631L * n + 354L
        val j = ((10985L - l) / 5316L) * ((50L * l) / 17719L) + (l / 5670L) * ((43L * l) / 15238L)
        l = l - ((30L - j) / 15L) * ((17719L * j) / 50L) - (j / 16L) * ((15238L * j) / 43L) + 29L
        val m = (24L * l) / 709L
        val day = l - (709L * m) / 24L
        val y = 30L * n + j - 30L
        return Hijri(y.toInt(), m.toInt(), day.toInt())
    }

    fun occasions(d: LocalDate): List<String> {
        val out = ArrayList<String>()
        val h = toHijri(d)
        if (h.month == 1 && h.day == 1) out.add("رأس السنة الهجرية")
        if (h.month == 1 && h.day == 10) out.add("يوم عاشوراء")
        if (h.month == 9 && h.day == 1) out.add("أول أيام رمضان")
        if (h.month == 10 && h.day == 1) out.add("عيد الفطر")
        if (h.month == 12 && h.day == 9) out.add("يوم عرفة")
        if (h.month == 12 && h.day == 10) out.add("عيد الأضحى")
        if (d.monthValue == 2 && d.dayOfMonth == 22) out.add("يوم التأسيس")
        if (d.monthValue == 3 && d.dayOfMonth == 11) out.add("يوم العلم")
        if (d.monthValue == 9 && d.dayOfMonth == 23) out.add("اليوم الوطني السعودي")
        return out
    }
}

data class UpItem(val icon: String, val title: String, val rel: String)

object Up {
    fun toArabicDigits(s: String): String {
        val w = "٠١٢٣٤٥٦٧٨٩"
        val sb = StringBuilder()
        for (c in s) sb.append(if (c.isDigit()) w[c - '0'] else c)
        return sb.toString()
    }

    private fun nextMonthly(day: Int, from: LocalDate): LocalDate {
        var d = from.withDayOfMonth(minOf(day, from.lengthOfMonth()))
        if (d.isBefore(from)) {
            val nm = from.plusMonths(1)
            d = nm.withDayOfMonth(minOf(day, nm.lengthOfMonth()))
        }
        return d
    }

    private fun relLabel(from: LocalDate, to: LocalDate): String {
        val diff = java.time.temporal.ChronoUnit.DAYS.between(from, to)
        val wk = Cal.weekdays[to.dayOfWeek.value % 7]
        val phrase = when {
            diff <= 0L -> "اليوم"
            diff == 1L -> "غدًا"
            diff < 11L -> "بعد ${diff} أيام"
            diff < 30L -> "بعد ${diff} يوم"
            else -> {
                val months = diff / 30; val rem = diff % 30
                val mTxt = if (months == 1L) "شهر واحد" else "$months أشهر"
                if (rem == 0L) "بعد $mTxt" else "بعد $mTxt و$rem يوم"
            }
        }
        val text = if (diff <= 0L) "$wk $phrase" else "$wk $phrase"
        return toArabicDigits(text)
    }

    fun list(today: LocalDate): List<UpItem> {
        val out = ArrayList<UpItem>()
        // اليوم الوطني (23 سبتمبر)
        val nat = nextMonthly(23, today.withMonth(9).withDayOfMonth(1)).let {
            if (it.isBefore(today)) LocalDate.of(today.year + 1, 9, 23) else LocalDate.of(today.year, 9, 23)
        }
        out.add(UpItem("🇸🇦", "اليوم الوطني", relLabel(today, nat)))

        val s1 = nextMonthly(Cal.SALARY_DAY, today)
        val s2 = nextMonthly(Cal.SALARY_DAY, s1.plusDays(1))
        val c1 = nextMonthly(Cal.CITIZEN_DAY, today)
        val c2 = nextMonthly(Cal.CITIZEN_DAY, c1.plusDays(1))
        out.add(UpItem("💰", "الرواتب الحكومية", relLabel(today, s1)))
        out.add(UpItem("💵", "حساب المواطن", relLabel(today, c1)))
        out.add(UpItem("💰", "الرواتب الحكومية", relLabel(today, s2)))
        out.add(UpItem("💵", "حساب المواطن", relLabel(today, c2)))
        return out
    }
}
