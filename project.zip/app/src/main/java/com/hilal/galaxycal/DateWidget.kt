package com.hilal.galaxycal

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.time.LocalDate

class DateWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        for (id in ids) {
            manager.updateAppWidget(id, build(context))
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED -> {
                val manager = AppWidgetManager.getInstance(context)
                val ids = manager.getAppWidgetIds(ComponentName(context, DateWidget::class.java))
                onUpdate(context, manager, ids)
            }
        }
    }

    private fun build(context: Context): RemoteViews {
        val today = LocalDate.now()
        val h = Cal.toHijri(today)
        val v = RemoteViews(context.packageName, R.layout.widget)
        v.setTextViewText(R.id.w_weekday, Cal.weekdays[today.dayOfWeek.value % 7])
        v.setTextViewText(R.id.w_day, today.dayOfMonth.toString())
        v.setTextViewText(R.id.w_hijri, "${h.day} ${Cal.hijriMonths[h.month - 1]} ${h.year} هـ")
        v.setTextViewText(R.id.w_greg, "${Cal.gregMonths[today.monthValue - 1]} ${today.year}")
        v.setTextViewText(R.id.w_occ, Cal.occasions(today).firstOrNull() ?: "")
        val pi = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        v.setOnClickPendingIntent(R.id.w_root, pi)
        return v
    }
}
