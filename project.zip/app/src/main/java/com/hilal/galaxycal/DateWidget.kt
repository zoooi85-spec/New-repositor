package com.hilal.galaxycal

import android.Manifest
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.widget.RemoteViews
import org.json.JSONArray
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime

class DateWidget : AppWidgetProvider() {

    // الرياض (افتراضي إذا ما فيه صلاحية موقع أو ما توفر آخر موقع معروف)
    private val defaultLat = 24.7136
    private val defaultLng = 46.6753

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        for (id in ids) manager.updateAppWidget(id, build(context))
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            Intent.ACTION_DATE_CHANGED, Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED -> {
                val manager = AppWidgetManager.getInstance(context)
                val ids = manager.getAppWidgetIds(ComponentName(context, DateWidget::class.java))
                onUpdate(context, manager, ids)
            }
        }
    }

    private fun lastLocation(context: Context): Pair<Double, Double> {
        try {
            if (context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED
            ) return defaultLat to defaultLng
            val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
                val loc = lm.getLastKnownLocation(p)
                if (loc != null) return loc.latitude to loc.longitude
            }
        } catch (e: Exception) {
        }
        return defaultLat to defaultLng
    }

    // يقرأ المواعيد اللي أضافها المستخدم من التطبيق ويحسب أقرب موعد قادم لكل واحد
    private fun readAppts(context: Context, today: LocalDate): List<UpItem> {
        try {
            val json = context.getSharedPreferences("widget_data", Context.MODE_PRIVATE)
                .getString("appts", "[]") ?: "[]"
            val arr = JSONArray(json)
            val out = ArrayList<UpItem>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val dateStr = o.optString("date", "")
                if (dateStr.isEmpty()) continue
                val start = try { LocalDate.parse(dateStr) } catch (e: Exception) { continue }
                val repeat = o.optString("repeat", "none")
                val done = o.optBoolean("done", false)
                val title = o.optString("title", "")
                val icon = o.optString("icon", "📌").ifEmpty { "📌" }
                val next = nextOccurrence(start, repeat, today) ?: continue
                if (repeat == "none" && done) continue
                out.add(UpItem(icon, title, next))
            }
            return out
        } catch (e: Exception) {
            return emptyList()
        }
    }

    private fun nextOccurrence(start: LocalDate, repeat: String, from: LocalDate): LocalDate? {
        if (start.isAfter(from)) return start
        return when (repeat) {
            "daily" -> from
            "weekly" -> {
                val diff = java.time.temporal.ChronoUnit.DAYS.between(start, from)
                val rem = diff % 7
                if (rem == 0L) from else from.plusDays(7 - rem)
            }
            "monthly" -> {
                var d = from.withDayOfMonth(minOf(start.dayOfMonth, from.lengthOfMonth()))
                if (d.isBefore(from)) {
                    val nm = from.plusMonths(1)
                    d = nm.withDayOfMonth(minOf(start.dayOfMonth, nm.lengthOfMonth()))
                }
                d
            }
            "yearly" -> {
                var d = try { LocalDate.of(from.year, start.monthValue, start.dayOfMonth) } catch (e: Exception) { return null }
                if (d.isBefore(from)) d = try { LocalDate.of(from.year + 1, start.monthValue, start.dayOfMonth) } catch (e: Exception) { return null }
                d
            }
            else -> if (start.isBefore(from)) null else start
        }
    }

    private fun build(context: Context): RemoteViews {
        val today = LocalDate.now()
        val h = Cal.toHijri(today)
        val now = ZonedDateTime.now(ZoneId.systemDefault())
        val tz = now.offset.totalSeconds / 3600.0
        val (lat, lng) = lastLocation(context)

        val pt = Prayer.compute(today, lat, lng, tz)

        val v = RemoteViews(context.packageName, R.layout.widget)
        v.setTextViewText(
            R.id.w_title,
            "${Cal.weekdays[today.dayOfWeek.value % 7]} ${h.day} ${Cal.hijriMonths[h.month - 1]} - ${today.dayOfMonth} ${Cal.gregMonths[today.monthValue - 1]}"
        )
        v.setTextViewText(R.id.w_date_g, Up.toArabicDigits("${today.dayOfMonth}-${today.monthValue}-${today.year} م"))
        v.setTextViewText(R.id.w_date_h, Up.toArabicDigits("${h.day}-${h.month}-${h.year} هـ"))
        v.setTextViewText(R.id.w_p0, "الفجر\n${Prayer.hhmm(pt.fajr)}")
        v.setTextViewText(R.id.w_p1, "الشروق\n${Prayer.hhmm(pt.sunrise)}")
        v.setTextViewText(R.id.w_p2, "الظهر\n${Prayer.hhmm(pt.dhuhr)}")
        v.setTextViewText(R.id.w_p3, "العصر\n${Prayer.hhmm(pt.asr)}")
        v.setTextViewText(R.id.w_p4, "المغرب\n${Prayer.hhmm(pt.maghrib)}")
        v.setTextViewText(R.id.w_p5, "العشاء\n${Prayer.hhmm(pt.isha)}")

        val items = Up.list(today, readAppts(context, today))
        val ids = intArrayOf(R.id.w_occ0, R.id.w_occ1, R.id.w_occ2, R.id.w_occ3, R.id.w_occ4)
        for (i in ids.indices) {
            if (i < items.size) {
                v.setTextViewText(ids[i], "${items[i].icon} ${items[i].title} - ${items[i].rel}")
            } else {
                v.setTextViewText(ids[i], "")
            }
        }

        val pi = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        v.setOnClickPendingIntent(R.id.w_root, pi)
        return v
    }
}
