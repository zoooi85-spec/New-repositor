package com.hilal.galaxycal

import android.Manifest
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var geoCallback: GeolocationPermissions.Callback? = null
    private var geoOrigin: String? = null

    // يحوّل إشعارات المتصفح (Notification) إلى إشعارات أندرويد
    private val shim = """<script>
(function(){
  function N(title, opts){ try{ AndroidBridge.notify(String(title), String((opts && opts.body) || '')); }catch(e){} }
  N.permission = 'granted';
  N.requestPermission = function(){ try{ AndroidBridge.askNotify(); }catch(e){} return Promise.resolve('granted'); };
  window.Notification = N;
})();
</script>"""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        val bg = Color.parseColor(if (night) "#1F1A13" else "#EFE6D6")
        window.statusBarColor = bg
        window.navigationBarColor = bg
        if (!night) {
            var flags = window.decorView.systemUiVisibility or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            flags = flags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            window.decorView.systemUiVisibility = flags
        }

        web = WebView(this)
        web.setBackgroundColor(bg)
        setContentView(web)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.setGeolocationEnabled(true)
        s.mediaPlaybackRequiresUserGesture = false

        web.addJavascriptInterface(Bridge(), "AndroidBridge")

        web.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(
                origin: String,
                callback: GeolocationPermissions.Callback
            ) {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) ==
                    PackageManager.PERMISSION_GRANTED
                ) {
                    callback.invoke(origin, true, false)
                } else {
                    geoOrigin = origin
                    geoCallback = callback
                    requestPermissions(
                        arrayOf(
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                        ), 1
                    )
                }
            }
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (request.url.host == "appassets.local") return false
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, request.url))
                } catch (e: Exception) {
                }
                return true
            }
        }

        val html = assets.open("index.html").bufferedReader(Charsets.UTF_8).use { it.readText() }
        val patched = html.replaceFirst("<head>", "<head>" + shim)
        web.loadDataWithBaseURL("https://appassets.local/", patched, "text/html", "utf-8", null)
    }

    inner class Bridge {
        @JavascriptInterface
        fun notify(title: String, body: String) {
            runOnUiThread { showNotification(title, body) }
        }

        @JavascriptInterface
        fun askNotify() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
                }
            }
        }

        // يحفظ مواعيد المستخدم بصيغة يقدر الويدجت يقرأها، ويحدّث الويدجت فوراً
        @JavascriptInterface
        fun saveAppts(json: String) {
            getSharedPreferences("widget_data", MODE_PRIVATE).edit().putString("appts", json).apply()
            runOnUiThread {
                val mgr = android.appwidget.AppWidgetManager.getInstance(this@MainActivity)
                val ids = mgr.getAppWidgetIds(android.content.ComponentName(this@MainActivity, DateWidget::class.java))
                if (ids.isNotEmpty()) {
                    val i = Intent(this@MainActivity, DateWidget::class.java)
                    i.action = android.appwidget.AppWidgetManager.ACTION_APPWIDGET_UPDATE
                    i.putExtra(android.appwidget.AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
                    sendBroadcast(i)
                }
            }
        }
    }

    private fun showNotification(title: String, body: String) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("alerts", "التنبيهات", NotificationManager.IMPORTANCE_HIGH)
        )
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "alerts")
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle(title)
            .setContentText(body)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify((System.currentTimeMillis() % 100000L).toInt(), n)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1) {
            val ok = grantResults.any { it == PackageManager.PERMISSION_GRANTED }
            geoCallback?.invoke(geoOrigin, ok, false)
            geoCallback = null
        }
    }

    // زر الرجوع: يقفل النافذة المفتوحة داخل الصفحة أولاً
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript(
            "(function(){var s=document.getElementById('sheet');" +
                "if(s && !s.hidden){ closeSheet(); return 'closed'; } return 'none';})()"
        ) { r ->
            if (r == null || !r.contains("closed")) {
                finish()
            }
        }
    }
}
