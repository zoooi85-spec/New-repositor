package com.hilal.galaxycal

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.time.LocalDate
import java.time.YearMonth

class MainActivity : Activity() {

    private val green = Color.parseColor("#1B5E20")
    private val orange = Color.parseColor("#E65100")
    private val grey = Color.parseColor("#757575")

    private var shown: YearMonth = YearMonth.now()
    private var selected: LocalDate = LocalDate.now()

    private lateinit var titleView: TextView
    private lateinit var subtitle: TextView
    private lateinit var grid: LinearLayout
    private lateinit var details: TextView

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun text(s: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        t.gravity = Gravity.CENTER
        if (bold) t.setTypeface(null, Typeface.BOLD)
        return t
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        root.setBackgroundColor(Color.WHITE)
        root.setPadding(dp(10), dp(28), dp(10), dp(10))

        // الترويسة: السابق - العنوان - التالي
        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL

        val prev = Button(this)
        prev.text = "السابق"
        prev.setOnClickListener { shown = shown.minusMonths(1); render() }

        val next = Button(this)
        next.text = "التالي"
        next.setOnClickListener { shown = shown.plusMonths(1); render() }

        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titleView = text("", 20f, green, true)
        subtitle = text("", 14f, grey)
        titles.addView(titleView)
        titles.addView(subtitle)

        header.addView(prev)
        header.addView(titles, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(next)
        root.addView(header)

        val todayBtn = Button(this)
        todayBtn.text = "اليوم"
        todayBtn.setOnClickListener {
            shown = YearMonth.now()
            selected = LocalDate.now()
            render()
        }
        root.addView(todayBtn)

        // أسماء الأيام
        val names = LinearLayout(this)
        names.orientation = LinearLayout.HORIZONTAL
        for (i in 0 until 7) {
            val color = if (i == 5) Color.parseColor("#B3261E") else grey
            names.addView(
                text(Cal.weekdaysShort[i], 12f, color, true),
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            )
        }
        root.addView(names)

        grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL
        root.addView(grid)

        details = text("", 16f, Color.BLACK)
        details.gravity = Gravity.CENTER
        details.setPadding(dp(8), dp(16), dp(8), dp(8))
        root.addView(details)

        setContentView(root)
        render()
    }

    private fun render() {
        val first = shown.atDay(1)
        val length = shown.lengthOfMonth()
        val h1 = Cal.toHijri(first)
        val h2 = Cal.toHijri(shown.atEndOfMonth())

        titleView.text = "${Cal.gregMonths[shown.monthValue - 1]} ${shown.year}"
        val a = "${Cal.hijriMonths[h1.month - 1]} ${h1.year}"
        val b = "${Cal.hijriMonths[h2.month - 1]} ${h2.year}"
        subtitle.text = (if (a == b) a else "$a – $b") + " هـ"

        grid.removeAllViews()
        val offset = first.dayOfWeek.value % 7   // الأحد = 0
        val today = LocalDate.now()
        var day = 1

        for (row in 0 until 6) {
            if (row * 7 >= offset + length) break
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL

            for (col in 0 until 7) {
                val idx = row * 7 + col
                val cell = LinearLayout(this)
                cell.orientation = LinearLayout.VERTICAL
                cell.gravity = Gravity.CENTER

                if (idx >= offset && day <= length) {
                    val date = shown.atDay(day)
                    val h = Cal.toHijri(date)
                    val hasOccasion = Cal.occasions(date).isNotEmpty()
                    val isSelected = date == selected
                    val isToday = date == today

                    val numColor = when {
                        isSelected -> Color.WHITE
                        col == 5 -> Color.parseColor("#B3261E")
                        else -> Color.BLACK
                    }
                    val hijriColor = when {
                        isSelected -> Color.WHITE
                        hasOccasion -> orange
                        else -> grey
                    }

                    cell.addView(text(date.dayOfMonth.toString(), 17f, numColor, true))
                    cell.addView(text(h.day.toString(), 11f, hijriColor, hasOccasion))

                    val bg = GradientDrawable()
                    bg.cornerRadius = dp(10).toFloat()
                    if (isSelected) bg.setColor(green)
                    if (isToday && !isSelected) bg.setStroke(dp(2), green)
                    cell.background = bg

                    cell.setOnClickListener {
                        selected = date
                        render()
                    }
                    day++
                }

                val lp = LinearLayout.LayoutParams(0, dp(56), 1f)
                lp.setMargins(dp(2), dp(2), dp(2), dp(2))
                r.addView(cell, lp)
            }
            grid.addView(r)
        }
        renderDetails()
    }

    private fun renderDetails() {
        val h = Cal.toHijri(selected)
        val sb = StringBuilder()
        sb.append(Cal.weekdays[selected.dayOfWeek.value % 7]).append("\n")
        sb.append("${h.day} ${Cal.hijriMonths[h.month - 1]} ${h.year} هـ").append("\n")
        sb.append("${selected.dayOfMonth} ${Cal.gregMonths[selected.monthValue - 1]} ${selected.year} م")
        for (o in Cal.occasions(selected)) {
            sb.append("\n• ").append(o)
        }
        details.text = sb.toString()
    }
}
