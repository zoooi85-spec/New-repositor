package com.hilal.galaxycal

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import org.json.JSONArray

// تنبيهات المواعيد والصلاة عن طريق منبّه النظام، فتوصل حتى لو التطبيق مقفل
object Alarms {
    private const val PREF = "alarms"

    fun schedule(context: Context, json: String) {
        val p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        p.edit().putString("list", json).apply()
        apply(context)
    }

    // يلغي القديم ويجدول القائمة المحفوظة (يُستدعى أيضاً بعد إعادة تشغيل الجوال)
    fun apply(context: Context) {
        val p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val old = p.getInt("count", 0)
        for (i in 0 until old) {
            am.cancel(pending(context, i, null, null, false))
        }
        val arr = try { JSONArray(p.getString("list", "[]") ?: "[]") } catch (e: Exception) { JSONArray() }
        val now = System.currentTimeMillis()
        var n = 0
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val t = o.optLong("t", 0L)
            if (t <= now) continue
            val pi = pending(context, n, o.optString("title"), o.optString("body"), o.optBoolean("prayer", false))
            val exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
            try {
                if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
                else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
            } catch (e: SecurityException) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
            }
            n++
        }
        p.edit().putInt("count", n).apply()
    }

    private fun pending(context: Context, i: Int, title: String?, body: String?, prayer: Boolean): PendingIntent {
        val intent = Intent(context, AlarmReceiver::class.java).setAction("com.hilal.galaxycal.ALARM")
        if (title != null) intent.putExtra("title", title)
        if (body != null) intent.putExtra("body", body)
        intent.putExtra("prayer", prayer)
        return PendingIntent.getBroadcast(
            context, 1000 + i, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun notify(context: Context, title: String, body: String, prayer: Boolean) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = if (prayer) "prayer" else "alerts"
        if (prayer) {
            val ch = NotificationChannel("prayer", "أوقات الصلاة", NotificationManager.IMPORTANCE_HIGH)
            ch.setSound(
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build()
            )
            nm.createNotificationChannel(ch)
        } else {
            nm.createNotificationChannel(NotificationChannel("alerts", "المواعيد", NotificationManager.IMPORTANCE_HIGH))
        }
        val open = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(context, channel)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(Notification.BigTextStyle().bigText(body))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify((System.currentTimeMillis() % 100000L).toInt(), n)
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED -> Alarms.apply(context)
            else -> Alarms.notify(
                context,
                intent.getStringExtra("title") ?: "تنبيه",
                intent.getStringExtra("body") ?: "",
                intent.getBooleanExtra("prayer", false)
            )
        }
    }
}
