package com.hilal.galaxycal

import android.content.Context
import org.json.JSONObject
import java.time.LocalDate

// يحفظ عدد خطوات كل يوم من حساس عدّاد الخطوات.
// الحساس يعطي مجموع الخطوات من آخر تشغيل للجوال، فنحفظ قراءة بداية اليوم ونطرحها.
object Steps {
    private const val PREF = "steps"

    fun onReading(context: Context, counter: Float) {
        val p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val today = LocalDate.now().toString()
        val c = counter.toLong()
        var day = p.getString("day", "") ?: ""
        var base = p.getLong("base", c)
        var acc = p.getLong("acc", 0L)
        val last = p.getLong("last", c)

        if (day != today) {
            // يوم جديد: الخطوات اللي بين آخر قراءة وبداية اليوم تنحسب لليوم الجديد
            day = today
            base = if (last <= c) last else 0L
            acc = 0L
        } else if (c < last) {
            // الجوال انطفى وشغّل: العداد رجع للصفر، نحفظ اللي قبل
            acc += last - base
            base = 0L
        }

        val todaySteps = (acc + c - base).coerceAtLeast(0L)
        val hist = try { JSONObject(p.getString("hist", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }
        hist.put(today, todaySteps)

        // نخلي آخر 400 يوم بس
        if (hist.length() > 400) {
            val keys = hist.keys().asSequence().toList().sorted()
            for (k in keys.take(hist.length() - 400)) hist.remove(k)
        }

        p.edit()
            .putString("day", day)
            .putLong("base", base)
            .putLong("acc", acc)
            .putLong("last", c)
            .putString("hist", hist.toString())
            .apply()
    }

    fun historyJson(context: Context): String =
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("hist", "{}") ?: "{}"
}
