package com.masroofi.app;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * يقرأ رسائل البنوك السعودية ويستخرج منها: المبلغ، نوع العملية، التاجر، البنك، والتصنيف.
 * مكتوب بجافا عادية بدون أي اعتماد على أندرويد عشان يسهل اختباره.
 */
public final class SmsParser {

    // أنواع العمليات
    public static final String PURCHASE = "PURCHASE";        // شراء
    public static final String WITHDRAWAL = "WITHDRAWAL";    // سحب نقدي
    public static final String TRANSFER_OUT = "TRANSFER_OUT";// حوالة صادرة
    public static final String TRANSFER_IN = "TRANSFER_IN";  // حوالة واردة
    public static final String DEPOSIT = "DEPOSIT";          // إيداع / راتب / استرداد

    public static final class Result {
        public double amount;      // المبلغ بعملته الأصلية
        public String currency;    // SAR, USD ...
        public double amountSar;   // المبلغ بالريال (تقريبي للعملات الأجنبية)
        public String type;
        public String merchant;
        public String bank;
        public String category;

        @Override
        public String toString() {
            return type + " | " + amount + " " + currency + " (" + amountSar + " SAR) | " + merchant + " | " + bank + " | " + category;
        }
    }

    private SmsParser() {}

    public static boolean isIncome(String type) {
        return DEPOSIT.equals(type) || TRANSFER_IN.equals(type);
    }

    // ---------------------------------------------------------------- normalize

    public static String normalize(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder(s.length());
        for (char c : s.toCharArray()) {
            if (c >= '٠' && c <= '٩') b.append((char) ('0' + (c - '٠')));       // ٠-٩
            else if (c >= '۰' && c <= '۹') b.append((char) ('0' + (c - '۰'))); // ۰-۹
            else if (c == '٫') b.append('.');   // ٫
            else if (c == '٬') b.append(',');   // ٬
            else if (c == 'ـ') continue;        // ـ (تطويل)
            else if (c == '‏' || c == '‎' || c == '‫' || c == '‬' || c == '‪') continue;
            else if (c == '\r') b.append('\n');
            else b.append(c);
        }
        return b.toString().replaceAll("[ \\t\\u00A0]+", " ");
    }

    // ---------------------------------------------------------------- patterns

    private static final int F = Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;
    private static final String NUM = "([0-9]{1,3}(?:,[0-9]{3})+(?:\\.[0-9]+)?|[0-9]+(?:\\.[0-9]+)?)";
    private static final String SAR = "(?:SAR|SR|S\\.R|ر\\.?[ ]?س\\.?|ريال|رس)";

    private static final Pattern SKIP = Pattern.compile(
            "رمز التحقق|رمز التفعيل|رمز الدخول|كلمة المرور لمرة|OTP|verification code|one[- ]time|"
            + "مرفوض|رفض|declined|لم تتم|غير ناجح|فشل|failed|insufficient|رصيد غير كاف", F);

    private static final Pattern BALANCE = Pattern.compile(
            "(?:الرصيد|رصيد|المتبقي|الحد المتاح|المتاح|Balance|Bal\\.?|Avail(?:able)?(?: Bal(?:ance)?)?)"
            + "\\s*(?:الحالي|المتاح|المتوفر)?\\s*[:：]?\\s*" + SAR + "?\\s*" + NUM + "\\s*" + SAR + "?", F);

    private static final Pattern AMT_KEYWORD = Pattern.compile(
            "(?:بمبلغ|المبلغ|مبلغ|Amount|Amt)[ \\t]*[:：]?[ \\t]*" + SAR + "?[ \\t]*" + NUM, F);
    private static final Pattern AMT_SAR_BEFORE = Pattern.compile(SAR + "[ \\t]*[:：]?[ \\t]*" + NUM, F);
    private static final Pattern AMT_SAR_AFTER = Pattern.compile(NUM + "[ \\t]*" + SAR + "(?![A-Za-z])", F);

    private static final String FX = "(USD|EUR|AED|GBP|KWD|BHD|QAR|OMR|EGP|JOD|TRY|\\$|دولار|درهم|يورو)";
    private static final Pattern AMT_FX_BEFORE = Pattern.compile(FX + "[ \\t]*[:：]?[ \\t]*" + NUM, F);
    private static final Pattern AMT_FX_AFTER = Pattern.compile(NUM + "[ \\t]*" + FX, F);
    private static final Pattern AMT_BA = Pattern.compile("(?:^|[ \\t\\n])بـ?[ \\t]*" + NUM + "(?=[ \\t\\n]|$)", F);

    private static final Map<String, Double> FX_RATES = new LinkedHashMap<>();
    static {
        // أسعار تقريبية للتحويل للريال
        FX_RATES.put("USD", 3.75); FX_RATES.put("EUR", 4.10); FX_RATES.put("AED", 1.02);
        FX_RATES.put("GBP", 4.80); FX_RATES.put("KWD", 12.2); FX_RATES.put("BHD", 9.95);
        FX_RATES.put("QAR", 1.03); FX_RATES.put("OMR", 9.74); FX_RATES.put("EGP", 0.077);
        FX_RATES.put("JOD", 5.29); FX_RATES.put("TRY", 0.11);
    }

    private static final Pattern MERCHANT_LINE = Pattern.compile(
            "^\\s*(لدى|لدي|عند|التاجر|المتجر|نقطة البيع|المفوتر|الجهة|الخدمة|Biller|المستفيد|إلى|الى|من|At|Merchant|Beneficiary|To|From)\\s*[:：]\\s*(.+?)\\s*$", F);
    private static final Pattern MERCHANT_INLINE = Pattern.compile(
            "(?:لدى|لدي|عند|التاجر|At|Merchant)\\s*[:：]?\\s+([^\\n،,;]{2,40}?)"
            + "(?=\\s+(?:في|بتاريخ|تاريخ|on|بمبلغ|مبلغ|بطاقة|Card|الرصيد|SAR|\\d{1,4}[/-]\\d)|\\s*[\\n،,;.]|\\s*$)", F);
    private static final Pattern MERCHANT_BAD = Pattern.compile(
            "^(بطاقة|حساب|card|account|مدى|mada|فيزا|visa|ماستر|master|\\*|[0-9*]+$)", F);

    // ---------------------------------------------------------------- parse

    /** يرجع null إذا الرسالة مو عملية مالية. */
    public static Result parse(String sender, String rawBody) {
        if (rawBody == null) return null;
        String senderStr = sender == null ? "" : sender.trim();
        // الأرقام الشخصية (جوالات) مو بنوك
        if (senderStr.replaceAll("[\\s-]", "").matches("^\\+?\\d{9,}$")) return null;

        String body = normalize(rawBody);
        if (SKIP.matcher(body).find()) return null;

        String type = detectType(body);
        if (type == null) return null;

        String clean = BALANCE.matcher(body).replaceAll(" ");

        Result r = new Result();
        r.type = type;
        r.currency = "SAR";

        Double amt = firstNumber(AMT_SAR_BEFORE, clean, 1);
        if (amt == null) amt = firstNumber(AMT_SAR_AFTER, clean, 1);

        if (amt == null) {
            Matcher m = AMT_FX_BEFORE.matcher(clean);
            if (m.find()) { r.currency = fxCode(m.group(1)); amt = toNumber(m.group(2)); }
            else {
                m = AMT_FX_AFTER.matcher(clean);
                if (m.find()) { r.currency = fxCode(m.group(2)); amt = toNumber(m.group(1)); }
            }
        }
        if (amt == null) amt = firstNumber(AMT_KEYWORD, clean, 1);
        if (amt == null) amt = firstNumber(AMT_BA, clean, 1);
        if (amt == null || amt <= 0 || amt > 10_000_000) return null;

        r.amount = amt;
        Double rate = FX_RATES.get(r.currency);
        r.amountSar = "SAR".equals(r.currency) || rate == null ? amt : Math.round(amt * rate * 100.0) / 100.0;
        r.merchant = extractMerchant(body, type);
        r.bank = bankName(senderStr);
        r.category = categorize(r.merchant, body, type);
        return r;
    }

    static String detectType(String b) {
        String l = b.toLowerCase(Locale.ROOT);
        if (has(l, "حوالة واردة", "حواله وارده", "تحويل وارد", "حوالة محلية واردة", "حوالة داخلية واردة",
                "incoming transfer", "transfer received", "credit transfer", "استلام حوالة", "تم استلام"))
            return TRANSFER_IN;
        if (has(l, "إيداع", "ايداع", "deposit", "راتب", "salary", "استرداد", "مسترد", "refund", "reversal", "عكس عملية"))
            return DEPOSIT;
        if (has(l, "شراء", "purchase", "pos ", "نقاط البيع", "نقطة بيع", "apple pay", "ابل باي", "أبل باي",
                "مدى باي", "عملية دفع", "دفع عبر", "دفع إلكتروني", "دفع الكتروني", "online payment", "e-commerce", "انترنت"))
            return PURCHASE;
        if (has(l, "سحب", "withdrawal", "atm", "صراف"))
            return WITHDRAWAL;
        if (has(l, "حوالة", "حواله", "تحويل", "transfer", "سريع", "sarie"))
            return TRANSFER_OUT;
        if (has(l, "سداد", "فاتورة", "payment", "دفع", "مدفوعات"))
            return PURCHASE;
        return null;
    }

    static String extractMerchant(String body, String type) {
        String best = null;
        int bestScore = -1;
        for (String line : body.split("\n")) {
            Matcher m = MERCHANT_LINE.matcher(line);
            if (!m.find()) continue;
            String key = m.group(1).toLowerCase(Locale.ROOT);
            String val = tidy(m.group(2));
            if (val.isEmpty() || MERCHANT_BAD.matcher(val).find()) continue;
            int score;
            if (key.equals("لدى") || key.equals("لدي") || key.equals("عند") || key.equals("التاجر") || key.equals("المتجر")
                    || key.equals("نقطة البيع") || key.equals("المفوتر") || key.equals("الجهة") || key.equals("الخدمة")
                    || key.equals("biller") || key.equals("at") || key.equals("merchant")) score = TRANSFER_IN.equals(type) ? 1 : 3;
            else if (key.equals("من") || key.equals("from")) score = TRANSFER_IN.equals(type) || DEPOSIT.equals(type) ? 3 : 0;
            else score = TRANSFER_OUT.equals(type) ? 3 : 1; // إلى / المستفيد
            if (score > bestScore) { bestScore = score; best = val; }
        }
        if (best != null) return best;

        Matcher m = MERCHANT_INLINE.matcher(body);
        while (m.find()) {
            String val = tidy(m.group(1));
            if (!val.isEmpty() && !MERCHANT_BAD.matcher(val).find()) return val;
        }
        switch (type) {
            case WITHDRAWAL: return "سحب نقدي";
            case DEPOSIT: return "إيداع";
            case TRANSFER_IN: return "حوالة واردة";
            case TRANSFER_OUT: return "حوالة صادرة";
            default: return "غير محدد";
        }
    }

    private static String tidy(String v) {
        if (v == null) return "";
        v = v.replaceAll("\\s+(?:في|بتاريخ|on)\\s+\\d.*$", "")
             .replaceAll("\\s+\\d{1,4}[/-]\\d{1,2}[/-]\\d{1,4}.*$", "")
             .replaceAll("[;,،.\\s]+$", "")
             .trim();
        if (v.length() > 40) v = v.substring(0, 40).trim();
        return v;
    }

    static String bankName(String sender) {
        String s = sender.toLowerCase(Locale.ROOT).replaceAll("[\\s_-]", "");
        String[][] map = {
                {"rajhi", "الراجحي"}, {"alahli", "الأهلي"}, {"snb", "الأهلي"}, {"ncb", "الأهلي"},
                {"alinma", "الإنماء"}, {"inma", "الإنماء"}, {"riyad", "الرياض"}, {"sabb", "ساب"}, {"sab", "ساب"},
                {"anb", "العربي الوطني"}, {"arabnational", "العربي الوطني"}, {"bilad", "البلاد"},
                {"fransi", "الفرنسي"}, {"bsf", "الفرنسي"}, {"jazira", "الجزيرة"}, {"saib", "الاستثمار"},
                {"stcpay", "STC Pay"}, {"stcbank", "STC Bank"}, {"urpay", "urpay"}, {"d360", "D360"},
                {"barq", "برق"}, {"mobilypay", "Mobily Pay"}, {"tiqmo", "tiqmo"}, {"emiratesnbd", "الإمارات دبي الوطني"},
                {"enbd", "الإمارات دبي الوطني"}, {"meem", "ميم"}, {"gib", "الخليج الدولي"}, {"vision", "فيجن بنك"},
        };
        for (String[] p : map) if (s.contains(p[0])) return p[1];
        return sender.isEmpty() ? "غير معروف" : sender;
    }

    // ---------------------------------------------------------------- categories

    public static final String[] CATEGORIES = {
            "مطاعم وقهوة", "بقالة", "وقود ومواصلات", "تسوق", "فواتير واشتراكات",
            "صحة", "ترفيه وسفر", "تحويلات", "سحب نقدي", "دخل", "أخرى"
    };

    private static final String[][] CAT_KEYWORDS = {
            {"مطاعم وقهوة", "STARBUCKS", "MCDONALD", "KFC", "ALBAIK", "BAIK", "HERFY", "KUDU", "CAFE", "COFFEE", "CAFFE",
                    "RESTAURANT", "PIZZA", "BURGER", "SHAWARMA", "HUNGERSTATION", "HUNGER STATION", "JAHEZ", "MRSOOL",
                    "TOYOU", "KEETA", "DUNKIN", "BARNS", "DR CAFE", "HALF MILLION", "TIM HORTONS", "DOMINO", "SUBWAY",
                    "مطعم", "كافيه", "كوفي", "قهوة", "شاورما", "هنقرستيشن", "جاهز", "مرسول", "البيك", "هرفي", "كودو", "بيتزا"},
            {"بقالة", "PANDA", "DANUBE", "TAMIMI", "OTHAIM", "CARREFOUR", "LULU", "NESTO", "FARM", "SUPERMARKET",
                    "MARKET", "HYPER", "NINJA", "NANA", "BINDAWOOD", "بقالة", "ماركت", "هايبر", "سوبر", "بنده", "الدانوب", "العثيم", "التميمي"},
            {"وقود ومواصلات", "ALDREES", "PETROMIN", "SASCO", "NAFT", "PETROL", "STATION", "UBER", "CAREEM", "BOLT",
                    "JEENY", "TAXI", "PARKING", "محطة", "وقود", "بنزين", "الدريس", "ساسكو", "أوبر", "كريم"},
            {"صحة", "PHARMACY", "NAHDI", "DAWAA", "HOSPITAL", "CLINIC", "MEDICAL", "صيدلية", "صيدليات", "النهدي", "الدواء", "مستشفى", "عيادة", "مستوصف"},
            {"ترفيه وسفر", "CINEMA", "VOX", "MUVI", "AMC", "HOTEL", "BOOKING", "AIRBNB", "SAUDIA", "FLYNAS", "FLYADEAL",
                    "ALMOSAFER", "GATHER", "سينما", "فندق", "طيران", "الخطوط", "المسافر"},
            {"فواتير واشتراكات", "STC", "MOBILY", "ZAIN", "SEC", "ELECTRICITY", "NETFLIX", "SHAHID", "SPOTIFY",
                    "APPLE.COM", "ITUNES", "GOOGLE", "ANGHAMI", "OSN", "YOUTUBE", "WATER", "سداد", "فاتورة", "كهرباء",
                    "مياه", "اتصالات", "موبايلي", "زين", "شاهد"},
            {"تسوق", "AMAZON", "NOON", "SHEIN", "NAMSHI", "IKEA", "CENTREPOINT", "JARIR", "EXTRA", "ZARA", "H&M",
                    "SALLA", "ZID", "MALL", "STORE", "SHOP", "متجر", "مول", "جرير", "اكسترا", "نون", "أمازون", "امازون", "سلة"},
    };

    public static String categorize(String merchant, String body, String type) {
        if (DEPOSIT.equals(type) || TRANSFER_IN.equals(type)) return "دخل";
        if (WITHDRAWAL.equals(type)) return "سحب نقدي";
        String m = " " + (merchant == null ? "" : merchant).toUpperCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}&.]+", " ") + " ";
        String b = body == null ? "" : body;
        for (String[] row : CAT_KEYWORDS) {
            for (int i = 1; i < row.length; i++) {
                String kw = row[i];
                if (kw.length() <= 4) {
                    if (m.contains(" " + kw + " ")) return row[0];
                } else if (m.contains(kw)) return row[0];
            }
        }
        if (b.contains("سداد") || b.contains("فاتورة")) return "فواتير واشتراكات";
        if (TRANSFER_OUT.equals(type)) return "تحويلات";
        return "أخرى";
    }

    // ---------------------------------------------------------------- helpers

    private static boolean has(String s, String... words) {
        for (String w : words) if (s.contains(w)) return true;
        return false;
    }

    private static Double firstNumber(Pattern p, String s, int group) {
        Matcher m = p.matcher(s);
        while (m.find()) {
            Double d = toNumber(m.group(group));
            if (d != null && d > 0) return d;
        }
        return null;
    }

    private static Double toNumber(String s) {
        if (s == null) return null;
        try { return Double.parseDouble(s.replace(",", "")); } catch (NumberFormatException e) { return null; }
    }

    private static String fxCode(String s) {
        String u = s.toUpperCase(Locale.ROOT);
        if (u.equals("$") || u.equals("دولار")) return "USD";
        if (u.equals("درهم")) return "AED";
        if (u.equals("يورو")) return "EUR";
        return u;
    }
}
