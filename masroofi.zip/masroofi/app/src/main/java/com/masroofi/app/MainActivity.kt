package com.masroofi.app

import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** حالة التطبيق كاملة */
class AppState(private val ctx: Context) {
    var txs by mutableStateOf(emptyList<Tx>())
        private set
    var hasPerm by mutableStateOf(false)
        private set
    var importing by mutableStateOf(false)
        private set
    var importProgress by mutableStateOf("")
        private set
    var message by mutableStateOf<String?>(null)

    private val main = Handler(Looper.getMainLooper())

    fun reload() {
        txs = TxDb.get(ctx).all()
        hasPerm = TxStore.hasSmsPermission(ctx)
    }

    fun importInbox() {
        if (importing) return
        if (!TxStore.hasSmsPermission(ctx)) {
            message = "فعّل صلاحية الرسائل أولاً"
            return
        }
        importing = true
        importProgress = "جاري قراءة الرسائل…"
        Thread {
            val added = try {
                TxStore.importInbox(ctx) { i, total -> main.post { importProgress = "جاري القراءة $i من $total" } }
            } catch (e: Exception) {
                -1
            }
            main.post {
                importing = false
                importProgress = ""
                reload()
                message = when {
                    added < 0 -> "صار خطأ أثناء قراءة الرسائل"
                    added == 0 -> "ما لقينا عمليات جديدة في الرسائل"
                    else -> "تمت إضافة $added عملية من رسائل البنك"
                }
            }
        }.start()
    }

    fun addManual(amount: Double, merchant: String, category: String, income: Boolean) {
        TxStore.addManual(ctx, amount, merchant, category, income)
        reload()
        message = "تمت الإضافة"
    }

    fun changeCategory(tx: Tx, category: String, forMerchant: Boolean) {
        val db = TxDb.get(ctx)
        if (forMerchant && tx.bank != "يدوي") {
            db.updateCategoryForMerchant(tx.merchant, category)
            MerchantRules.set(ctx, tx.merchant, category)
        } else {
            db.updateCategory(tx.id, category)
        }
        reload()
    }

    fun delete(tx: Tx) {
        TxDb.get(ctx).delete(tx.id)
        reload()
        message = "تم الحذف"
    }

    fun clearAll() {
        TxDb.get(ctx).clear()
        reload()
        message = "تم حذف كل البيانات"
    }
}

class MainActivity : ComponentActivity() {
    private lateinit var state: AppState

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        state = AppState(applicationContext)
        state.reload()
        setContent { MasroofiApp(state) }
    }

    override fun onResume() {
        super.onResume()
        state.reload()
        TxStore.onChange = { runOnUiThread { state.reload() } }
    }

    override fun onPause() {
        super.onPause()
        TxStore.onChange = null
    }
}
