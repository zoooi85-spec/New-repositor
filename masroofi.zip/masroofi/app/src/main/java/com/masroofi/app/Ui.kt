@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.masroofi.app

import android.Manifest
import android.content.Intent
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ------------------------------------------------------------------ الألوان (أبيض وأزرق)

val Blue = Color(0xFF1E5BD8)
val BlueDark = Color(0xFF123C9C)
val BlueLight = Color(0xFF4C8DF6)
val BlueSoft = Color(0xFFE9F0FE)
val Bg = Color(0xFFF6F8FC)
val TextMain = Color(0xFF14213D)
val TextSub = Color(0xFF6B7690)
val Green = Color(0xFF16A34A)
val Red = Color(0xFFDC2626)

private val colors = lightColorScheme(
    primary = Blue, onPrimary = Color.White,
    primaryContainer = BlueSoft, onPrimaryContainer = BlueDark,
    secondary = BlueLight, onSecondary = Color.White,
    secondaryContainer = BlueSoft, onSecondaryContainer = BlueDark,
    background = Bg, onBackground = TextMain,
    surface = Color.White, onSurface = TextMain,
    surfaceVariant = BlueSoft, onSurfaceVariant = TextSub,
    surfaceContainer = Color.White, surfaceContainerLow = Color.White,
    surfaceContainerHigh = Color.White, surfaceContainerHighest = BlueSoft,
    outline = Color(0xFFD5DEEE), error = Red,
)

private val arLocale: Locale = Locale.forLanguageTag("ar-u-nu-latn")

fun categoryEmoji(cat: String): String = when (cat) {
    "مطاعم وقهوة" -> "☕"
    "بقالة" -> "🛒"
    "وقود ومواصلات" -> "🚗"
    "تسوق" -> "🛍️"
    "فواتير واشتراكات" -> "🧾"
    "صحة" -> "💊"
    "ترفيه وسفر" -> "✈️"
    "تحويلات" -> "🔁"
    "سحب نقدي" -> "💵"
    "دخل" -> "💰"
    else -> "📌"
}

// ------------------------------------------------------------------ أدوات التاريخ

fun monthStart(offset: Int = 0): Long = Calendar.getInstance().apply {
    set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
    set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0); add(Calendar.MONTH, offset)
}.timeInMillis

fun monthName(start: Long): String = SimpleDateFormat("MMMM yyyy", arLocale).format(Date(start))
fun shortMonth(start: Long): String = SimpleDateFormat("MMM", arLocale).format(Date(start))
fun dayHeader(ts: Long): String = SimpleDateFormat("EEEE d MMMM", arLocale).format(Date(ts))
fun timeText(ts: Long): String = SimpleDateFormat("h:mm a", arLocale).format(Date(ts))
fun fullDate(ts: Long): String = SimpleDateFormat("d MMMM yyyy - h:mm a", arLocale).format(Date(ts))
fun dayKey(ts: Long): String = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date(ts))

fun List<Tx>.inMonth(offset: Int): List<Tx> {
    val s = monthStart(offset); val e = monthStart(offset + 1)
    return filter { it.timestamp in s until e }
}
fun List<Tx>.expenses() = filter { !it.isIncome }.sumOf { it.amountSar }
fun List<Tx>.income() = filter { it.isIncome }.sumOf { it.amountSar }

// ------------------------------------------------------------------ التطبيق

private enum class Tab(val title: String, val icon: ImageVector) {
    Home("الرئيسية", Icons.Filled.Home),
    List("العمليات", Icons.Filled.List),
    Reports("التقارير", Icons.Filled.DateRange),
    Settings("الإعدادات", Icons.Filled.Settings),
}

@Composable
fun MasroofiApp(state: AppState) {
    MaterialTheme(colorScheme = colors) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            var tab by remember { mutableStateOf(Tab.Home) }
            var showAdd by remember { mutableStateOf(false) }
            var selected by remember { mutableStateOf<Tx?>(null) }
            val snackbar = remember { SnackbarHostState() }

            val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
                state.reload()
                if (res[Manifest.permission.READ_SMS] == true && res[Manifest.permission.RECEIVE_SMS] == true) {
                    state.importInbox()
                } else {
                    state.message = "بدون صلاحية الرسائل تقدر تضيف عملياتك يدوياً"
                }
            }
            val askPermission: () -> Unit = {
                val perms = mutableListOf(Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS)
                if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
                permLauncher.launch(perms.toTypedArray())
            }

            LaunchedEffect(state.message) {
                state.message?.let { snackbar.showSnackbar(it); state.message = null }
            }

            Scaffold(
                containerColor = Bg,
                snackbarHost = { SnackbarHost(snackbar) },
                bottomBar = {
                    NavigationBar(containerColor = Color.White, tonalElevation = 0.dp) {
                        Tab.entries.forEach { t ->
                            NavigationBarItem(
                                selected = tab == t,
                                onClick = { tab = t },
                                icon = { Icon(t.icon, contentDescription = t.title) },
                                label = { Text(t.title, fontSize = 12.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Blue, selectedTextColor = Blue,
                                    indicatorColor = BlueSoft, unselectedIconColor = TextSub, unselectedTextColor = TextSub
                                )
                            )
                        }
                    }
                },
                floatingActionButton = {
                    if (tab == Tab.Home || tab == Tab.List) {
                        FloatingActionButton(onClick = { showAdd = true }, containerColor = Blue, contentColor = Color.White) {
                            Icon(Icons.Filled.Add, contentDescription = "إضافة")
                        }
                    }
                }
            ) { pad ->
                Box(Modifier.padding(pad).fillMaxSize()) {
                    when (tab) {
                        Tab.Home -> HomeScreen(state, askPermission, onOpen = { selected = it }, onSeeAll = { tab = Tab.List })
                        Tab.List -> TransactionsScreen(state, onOpen = { selected = it })
                        Tab.Reports -> ReportsScreen(state)
                        Tab.Settings -> SettingsScreen(state, askPermission)
                    }
                }
            }

            if (showAdd) AddDialog(onDismiss = { showAdd = false }) { amount, merchant, cat, income ->
                state.addManual(amount, merchant, cat, income); showAdd = false
            }
            selected?.let { tx ->
                TxDialog(tx,
                    onDismiss = { selected = null },
                    onSave = { cat, all -> state.changeCategory(tx, cat, all); selected = null },
                    onDelete = { state.delete(tx); selected = null })
            }
        }
    }
}

// ------------------------------------------------------------------ الرئيسية

@Composable
private fun HomeScreen(state: AppState, askPermission: () -> Unit, onOpen: (Tx) -> Unit, onSeeAll: () -> Unit) {
    val month = state.txs.inMonth(0)
    val lastMonth = state.txs.inMonth(-1)
    LazyColumn(contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("أهلاً بك 👋", color = TextSub, fontSize = 14.sp)
                    Text("مصروفي", color = TextMain, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        item { SummaryCard(month, lastMonth) }
        if (!state.hasPerm) item { PermissionCard(askPermission) }
        if (state.importing) item { InfoCard("⏳", state.importProgress) }

        val cats = month.filter { !it.isIncome }.groupBy { it.category }
            .map { it.key to it.value.sumOf { t -> t.amountSar } }.sortedByDescending { it.second }.take(4)
        if (cats.isNotEmpty()) {
            item { SectionTitle("أكثر ما صرفت عليه هذا الشهر") }
            item {
                Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(Color.White)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        val total = cats.sumOf { it.second }.coerceAtLeast(1.0)
                        cats.forEach { (c, v) -> CategoryBar(c, v, v / total) }
                    }
                }
            }
        }

        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SectionTitle("آخر العمليات", Modifier.weight(1f))
                if (state.txs.isNotEmpty()) TextButton(onClick = onSeeAll) { Text("عرض الكل", color = Blue) }
            }
        }
        if (state.txs.isEmpty()) {
            item {
                EmptyState(
                    if (state.hasPerm) "ما فيه عمليات للحين.\nأول ما توصلك رسالة من البنك بتنضاف هنا تلقائياً."
                    else "فعّل قراءة رسائل البنك، أو اضغط + وأضف عملية يدوياً."
                )
            }
        } else {
            item {
                Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(Color.White)) {
                    Column {
                        state.txs.take(8).forEachIndexed { i, t ->
                            if (i > 0) HorizontalDivider(color = Bg, modifier = Modifier.padding(horizontal = 16.dp))
                            TxRow(t, onClick = { onOpen(t) })
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SummaryCard(month: List<Tx>, lastMonth: List<Tx>) {
    val spent = month.expenses()
    val income = month.income()
    val prev = lastMonth.expenses()
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(listOf(Blue, BlueDark)))
            .padding(20.dp)
    ) {
        Column {
            Text("مصروفات ${monthName(monthStart(0))}", color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp)
            Spacer(Modifier.height(6.dp))
            Text(formatMoney(spent), color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
            if (prev > 0) {
                val diff = (spent - prev) / prev * 100
                val txt = if (diff >= 0) "▲ أكثر من الشهر الماضي بـ ${"%.0f".format(Locale.US, diff)}٪"
                else "▼ أقل من الشهر الماضي بـ ${"%.0f".format(Locale.US, -diff)}٪"
                Text(txt, color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
            }
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MiniStat("الدخل", formatMoney(income), Modifier.weight(1f))
                MiniStat("الصافي", formatMoney(income - spent), Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun MiniStat(label: String, value: String, modifier: Modifier) {
    Column(modifier.clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.14f)).padding(12.dp)) {
        Text(label, color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
        Text(value, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
private fun PermissionCard(onClick: () -> Unit) {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(BlueSoft)) {
        Column(Modifier.padding(16.dp)) {
            Text("📩 تسجيل تلقائي لمصاريفك", fontWeight = FontWeight.Bold, color = BlueDark, fontSize = 16.sp)
            Spacer(Modifier.height(4.dp))
            Text(
                "اسمح للتطبيق يقرأ رسائل البنك، وكل عملية شراء أو حوالة تنضاف لحالها. الرسائل ما تطلع من جوالك أبداً.",
                color = TextMain, fontSize = 14.sp
            )
            Spacer(Modifier.height(12.dp))
            Button(onClick = onClick, colors = ButtonDefaults.buttonColors(Blue), shape = RoundedCornerShape(12.dp)) {
                Text("تفعيل قراءة رسائل البنك")
            }
        }
    }
}

@Composable
private fun InfoCard(icon: String, text: String) {
    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(Color.White)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(icon, fontSize = 20.sp); Spacer(Modifier.width(10.dp))
            Text(text, color = TextMain, modifier = Modifier.weight(1f))
            CircularProgressIndicator(Modifier.size(20.dp), color = Blue, strokeWidth = 2.dp)
        }
    }
}

@Composable
private fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, modifier = modifier.padding(top = 4.dp), fontSize = 17.sp, fontWeight = FontWeight.Bold, color = TextMain)
}

@Composable
private fun EmptyState(text: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("🧾", fontSize = 44.sp)
        Spacer(Modifier.height(8.dp))
        Text(text, color = TextSub, textAlign = TextAlign.Center, fontSize = 14.sp)
    }
}

@Composable
private fun CategoryBar(cat: String, value: Double, fraction: Double) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(categoryEmoji(cat), fontSize = 16.sp); Spacer(Modifier.width(8.dp))
            Text(cat, color = TextMain, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Text(formatMoney(value), color = TextMain, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text("  ${"%.0f".format(Locale.US, fraction * 100)}٪", color = TextSub, fontSize = 12.sp)
        }
        Spacer(Modifier.height(6.dp))
        Box(Modifier.fillMaxWidth().height(8.dp).clip(CircleShape).background(BlueSoft)) {
            Box(Modifier.fillMaxWidth(fraction.toFloat().coerceIn(0.02f, 1f)).fillMaxHeight().clip(CircleShape).background(Blue))
        }
    }
}

@Composable
private fun TxRow(t: Tx, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(44.dp).clip(CircleShape).background(BlueSoft), contentAlignment = Alignment.Center) {
            Text(categoryEmoji(t.category), fontSize = 20.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(t.merchant, color = TextMain, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${t.category} • ${t.bank} • ${timeText(t.timestamp)}", color = TextSub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.End) {
            Text(
                (if (t.isIncome) "+" else "-") + formatMoney(t.amountSar),
                color = if (t.isIncome) Green else TextMain, fontWeight = FontWeight.Bold, fontSize = 15.sp
            )
            if (t.currency != "SAR") {
                Text(String.format(Locale.US, "%.2f %s", t.amount, t.currency), color = TextSub, fontSize = 11.sp)
            }
        }
    }
}

// ------------------------------------------------------------------ العمليات

@Composable
private fun TransactionsScreen(state: AppState, onOpen: (Tx) -> Unit) {
    var query by remember { mutableStateOf("") }
    var mode by remember { mutableIntStateOf(0) } // 0 الكل، 1 مصروفات، 2 دخل
    val list = state.txs.filter {
        (mode == 0 || (mode == 1 && !it.isIncome) || (mode == 2 && it.isIncome)) &&
            (query.isBlank() || it.merchant.contains(query, true) || it.category.contains(query) || it.bank.contains(query, true))
    }
    val grouped = list.groupBy { dayKey(it.timestamp) }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.background(Color.White).padding(16.dp)) {
            Text("العمليات", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = TextMain)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("ابحث باسم التاجر أو التصنيف") }, singleLine = true,
                leadingIcon = { Icon(Icons.Filled.Search, null) }, shape = RoundedCornerShape(14.dp)
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("الكل", "المصروفات", "الدخل").forEachIndexed { i, l ->
                    FilterChip(selected = mode == i, onClick = { mode = i }, label = { Text(l) },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Blue, selectedLabelColor = Color.White))
                }
            }
        }
        if (list.isEmpty()) {
            EmptyState("ما فيه عمليات")
        } else {
            LazyColumn(contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 96.dp)) {
                grouped.forEach { (_, items) ->
                    item {
                        Row(Modifier.padding(top = 12.dp, bottom = 6.dp)) {
                            Text(dayHeader(items.first().timestamp), color = TextSub, fontSize = 13.sp, modifier = Modifier.weight(1f))
                            Text("-" + formatMoney(items.expenses()), color = TextSub, fontSize = 13.sp)
                        }
                    }
                    item {
                        Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(Color.White)) {
                            Column {
                                items.forEachIndexed { i, t ->
                                    if (i > 0) HorizontalDivider(color = Bg, modifier = Modifier.padding(horizontal = 16.dp))
                                    TxRow(t, onClick = { onOpen(t) })
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ التقارير

@Composable
private fun ReportsScreen(state: AppState) {
    var offset by remember { mutableIntStateOf(0) }
    val month = state.txs.inMonth(offset)
    val spent = month.expenses()
    val income = month.income()
    val cats = month.filter { !it.isIncome }.groupBy { it.category }
        .map { it.key to it.value.sumOf { t -> t.amountSar } }.sortedByDescending { it.second }
    val merchants = month.filter { !it.isIncome }.groupBy { it.merchant }
        .map { Triple(it.key, it.value.size, it.value.sumOf { t -> t.amountSar }) }.sortedByDescending { it.third }.take(5)
    val days = Calendar.getInstance().apply { timeInMillis = monthStart(offset) }.getActualMaximum(Calendar.DAY_OF_MONTH)
    val daysPassed = if (offset == 0) Calendar.getInstance().get(Calendar.DAY_OF_MONTH) else days

    LazyColumn(contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 32.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("التقارير", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = TextMain, modifier = Modifier.weight(1f))
                IconButton(onClick = { offset-- }) { Icon(Icons.Filled.KeyboardArrowRight, "الشهر السابق", tint = Blue) }
                Text(monthName(monthStart(offset)), color = TextMain, fontWeight = FontWeight.SemiBold)
                IconButton(onClick = { if (offset < 0) offset++ }, enabled = offset < 0) {
                    Icon(Icons.Filled.KeyboardArrowLeft, "الشهر التالي", tint = if (offset < 0) Blue else TextSub.copy(alpha = 0.3f))
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("المصروفات", formatMoney(spent), TextMain, Modifier.weight(1f))
                StatCard("الدخل", formatMoney(income), Green, Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("متوسط اليوم", formatMoney(if (daysPassed > 0) spent / daysPassed else 0.0), Blue, Modifier.weight(1f))
                StatCard("عدد العمليات", month.size.toString(), Blue, Modifier.weight(1f))
            }
        }
        item { SectionTitle("آخر ٦ أشهر") }
        item { SixMonthsChart(state.txs, offset) }
        item { SectionTitle("حسب التصنيف") }
        item {
            Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(Color.White)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    if (cats.isEmpty()) Text("ما فيه مصروفات في هذا الشهر", color = TextSub)
                    val total = spent.coerceAtLeast(1.0)
                    cats.forEach { (c, v) -> CategoryBar(c, v, v / total) }
                }
            }
        }
        if (merchants.isNotEmpty()) {
            item { SectionTitle("أكثر التجار") }
            item {
                Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(Color.White)) {
                    Column(Modifier.padding(vertical = 4.dp)) {
                        merchants.forEachIndexed { i, (name, count, sum) ->
                            if (i > 0) HorizontalDivider(color = Bg, modifier = Modifier.padding(horizontal = 16.dp))
                            Row(Modifier.padding(16.dp, 12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(28.dp).clip(CircleShape).background(BlueSoft), contentAlignment = Alignment.Center) {
                                    Text("${i + 1}", color = Blue, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(name, color = TextMain, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("$count عملية", color = TextSub, fontSize = 12.sp)
                                }
                                Text(formatMoney(sum), color = TextMain, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, color: Color, modifier: Modifier) {
    Card(modifier, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(Color.White)) {
        Column(Modifier.padding(14.dp)) {
            Text(label, color = TextSub, fontSize = 12.sp)
            Spacer(Modifier.height(4.dp))
            Text(value, color = color, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }
}

@Composable
private fun SixMonthsChart(all: List<Tx>, selected: Int) {
    val data = (selected - 5..selected).map { o -> o to all.inMonth(o).expenses() }
    val max = data.maxOf { it.second }.coerceAtLeast(1.0)
    val chartHeight: Dp = 120.dp
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(Color.White)) {
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.Bottom
        ) {
            // الأقدم يمين والأحدث يسار (اتجاه القراءة العربي)
            data.forEach { (o, v) ->
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                    Text(if (v >= 1000) "%.1fk".format(Locale.US, v / 1000) else "%.0f".format(Locale.US, v), fontSize = 10.sp, color = TextSub)
                    Spacer(Modifier.height(4.dp))
                    Box(
                        Modifier.width(22.dp).height(chartHeight * (v / max).toFloat().coerceIn(0.03f, 1f))
                            .clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                            .background(if (o == selected) Blue else BlueSoft)
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(shortMonth(monthStart(o)), fontSize = 11.sp, color = if (o == selected) Blue else TextSub, maxLines = 1)
                }
            }
        }
    }
}

// ------------------------------------------------------------------ الإعدادات

@Composable
private fun SettingsScreen(state: AppState, askPermission: () -> Unit) {
    val ctx = LocalContext.current
    var confirmClear by remember { mutableStateOf(false) }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("الإعدادات", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = TextMain) }
        item {
            SettingCard(
                "📩", "قراءة رسائل البنك",
                if (state.hasPerm) "مفعّلة ✓ — العمليات الجديدة تنضاف تلقائياً" else "غير مفعّلة",
                if (state.hasPerm) null else "تفعيل", onClick = askPermission
            )
        }
        item {
            SettingCard(
                "🔄", "استيراد الرسائل القديمة",
                if (state.importing) state.importProgress else "يقرأ رسائل البنك الموجودة في جوالك ويضيف العمليات اللي فاتت",
                if (state.importing) null else "استيراد", onClick = { state.importInbox() }
            )
        }
        item {
            SettingCard("📊", "تصدير إلى إكسل", "ملف CSV فيه كل عملياتك تقدر تفتحه في إكسل أو تشاركه", "تصدير") {
                val f = TxStore.exportCsv(ctx)
                val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/csv"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                ctx.startActivity(Intent.createChooser(send, "تصدير العمليات"))
            }
        }
        item {
            SettingCard("🗑️", "حذف كل البيانات", "يمسح كل العمليات المسجلة في التطبيق", "حذف", danger = true) { confirmClear = true }
        }
        item {
            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(BlueSoft)) {
                Column(Modifier.padding(16.dp)) {
                    Text("🔒 خصوصيتك", fontWeight = FontWeight.Bold, color = BlueDark)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "كل بياناتك محفوظة على جوالك فقط. التطبيق ما يرسل أي رسالة أو عملية لأي سيرفر، ويتجاهل رموز التحقق (OTP) والرسائل الشخصية.",
                        color = TextMain, fontSize = 13.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    Text("🏦 البنوك المدعومة", fontWeight = FontWeight.Bold, color = BlueDark)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "الراجحي، الأهلي، الإنماء، الرياض، ساب، العربي، البلاد، الفرنسي، الجزيرة، الاستثمار، STC Pay، STC Bank، urpay، D360، برق، Mobily Pay، وأغلب البنوك اللي ترسل رسائل بالعربي أو الإنجليزي.",
                        color = TextMain, fontSize = 13.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    Text("مصروفي • الإصدار 1.0", color = TextSub, fontSize = 12.sp)
                }
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            containerColor = Color.White,
            title = { Text("حذف كل البيانات؟") },
            text = { Text("بيتم مسح كل العمليات. تقدر ترجعها باستيراد الرسائل القديمة مرة ثانية.") },
            confirmButton = {
                TextButton(onClick = { state.clearAll(); confirmClear = false }) { Text("حذف", color = Red) }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("إلغاء", color = Blue) } }
        )
    }
}

@Composable
private fun SettingCard(
    icon: String, title: String, sub: String, action: String?,
    danger: Boolean = false, onClick: () -> Unit
) {
    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(Color.White)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(CircleShape).background(BlueSoft), contentAlignment = Alignment.Center) { Text(icon, fontSize = 18.sp) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold, color = TextMain)
                Text(sub, color = TextSub, fontSize = 12.sp)
            }
            if (action != null) {
                Spacer(Modifier.width(8.dp))
                if (danger) OutlinedButton(onClick = onClick, shape = RoundedCornerShape(12.dp)) { Text(action, color = Red) }
                else Button(onClick = onClick, colors = ButtonDefaults.buttonColors(Blue), shape = RoundedCornerShape(12.dp)) { Text(action) }
            }
        }
    }
}

// ------------------------------------------------------------------ النوافذ

@Composable
private fun CategoryPicker(selected: String, options: List<String>, onSelect: (String) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        options.forEach { c ->
            FilterChip(
                selected = c == selected, onClick = { onSelect(c) },
                label = { Text("${categoryEmoji(c)} $c", fontSize = 13.sp) },
                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Blue, selectedLabelColor = Color.White)
            )
        }
    }
}

@Composable
private fun AddDialog(onDismiss: () -> Unit, onSave: (Double, String, String, Boolean) -> Unit) {
    var amountText by remember { mutableStateOf("") }
    var merchant by remember { mutableStateOf("") }
    var income by remember { mutableStateOf(false) }
    var category by remember { mutableStateOf("أخرى") }
    val amount = SmsParser.normalize(amountText).replace(",", "").trim().toDoubleOrNull()

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        title = { Text("إضافة عملية") },
        text = {
            Column(Modifier.verticalScrollCompat(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !income, onClick = { income = false }, label = { Text("مصروف") },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Blue, selectedLabelColor = Color.White))
                    FilterChip(selected = income, onClick = { income = true }, label = { Text("دخل") },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Green, selectedLabelColor = Color.White))
                }
                OutlinedTextField(
                    value = amountText, onValueChange = { amountText = it }, label = { Text("المبلغ (ر.س)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = merchant, onValueChange = { merchant = it },
                    label = { Text(if (income) "المصدر (اختياري)" else "المكان / التاجر") },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                if (!income) {
                    Text("التصنيف", color = TextSub, fontSize = 13.sp)
                    CategoryPicker(category, SmsParser.CATEGORIES.filter { it != "دخل" }) { category = it }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { amount?.let { onSave(it, merchant.trim(), if (income) "دخل" else category, income) } },
                enabled = amount != null && amount > 0,
                colors = ButtonDefaults.buttonColors(Blue)
            ) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء", color = Blue) } }
    )
}

@Composable
private fun TxDialog(tx: Tx, onDismiss: () -> Unit, onSave: (String, Boolean) -> Unit, onDelete: () -> Unit) {
    var category by remember { mutableStateOf(tx.category) }
    var applyAll by remember { mutableStateOf(tx.bank != "يدوي") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        title = { Text(tx.merchant, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(Modifier.verticalScrollCompat(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    (if (tx.isIncome) "+" else "-") + formatMoney(tx.amountSar),
                    fontSize = 26.sp, fontWeight = FontWeight.Bold, color = if (tx.isIncome) Green else TextMain
                )
                if (tx.currency != "SAR") {
                    Text(
                        String.format(Locale.US, "المبلغ الأصلي: %.2f %s (التحويل للريال تقريبي)", tx.amount, tx.currency),
                        color = TextSub, fontSize = 12.sp
                    )
                }
                DetailLine("النوع", typeLabel(tx.type))
                DetailLine("البنك", tx.bank)
                DetailLine("التاريخ", fullDate(tx.timestamp))
                Spacer(Modifier.height(4.dp))
                Text("التصنيف", color = TextSub, fontSize = 13.sp)
                CategoryPicker(category, SmsParser.CATEGORIES.toList()) { category = it }
                if (tx.bank != "يدوي") {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { applyAll = !applyAll }) {
                        Checkbox(checked = applyAll, onCheckedChange = { applyAll = it }, colors = CheckboxDefaults.colors(checkedColor = Blue))
                        Text("طبّق على كل عمليات «${tx.merchant}»", fontSize = 13.sp, color = TextMain)
                    }
                }
                if (tx.raw.isNotBlank()) {
                    Text("رسالة البنك", color = TextSub, fontSize = 13.sp)
                    Text(
                        tx.raw, fontSize = 12.sp, color = TextMain,
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Bg).padding(10.dp)
                    )
                }
                TextButton(onClick = onDelete) {
                    Icon(Icons.Filled.Delete, null, tint = Red); Spacer(Modifier.width(4.dp)); Text("حذف العملية", color = Red)
                }
            }
        },
        confirmButton = {
            Button(onClick = { onSave(category, applyAll) }, colors = ButtonDefaults.buttonColors(Blue)) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إغلاق", color = Blue) } }
    )
}

@Composable
private fun DetailLine(label: String, value: String) {
    Row {
        Text(label, color = TextSub, fontSize = 14.sp, modifier = Modifier.width(70.dp))
        Text(value, color = TextMain, fontSize = 14.sp)
    }
}

@Composable
private fun Modifier.verticalScrollCompat(): Modifier =
    this.verticalScroll(androidx.compose.foundation.rememberScrollState())
