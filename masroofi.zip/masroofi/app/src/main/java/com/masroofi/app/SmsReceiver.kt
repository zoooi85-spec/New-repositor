package com.masroofi.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

/** يستقبل رسائل البنك الجديدة لحظة وصولها ويسجّلها تلقائياً */
class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        if (messages.isEmpty()) return

        // الرسالة الطويلة توصل على أجزاء — نجمعها حسب المرسل
        val bySender = messages.filterNotNull().groupBy { it.originatingAddress ?: "" }
        var changed = false
        for ((sender, parts) in bySender) {
            val body = parts.joinToString("") { it.messageBody ?: "" }
            val ts = parts.first().timestampMillis.takeIf { it > 0 } ?: System.currentTimeMillis()
            val tx = TxStore.handleSms(context, sender, body, ts)
            if (tx != null) {
                changed = true
                TxStore.notifyNew(context, tx)
            }
        }
        if (changed) TxStore.onChange?.invoke()
    }
}
