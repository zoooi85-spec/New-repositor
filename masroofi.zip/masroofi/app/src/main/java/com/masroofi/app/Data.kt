package com.masroofi.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Build
import android.provider.Telephony
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** عملية مالية واحدة */
data class Tx(
    val id: Long = 0,
    val amount: Double,
    val currency: String = "SAR",
    val amountSar: Double,
    val type: String,
    val merchant: String,
    val category: String,
    val bank: String,
    val timestamp: Long,
    val raw: String = "",
) {
    val isIncome: Boolean get() = SmsParser.isIncome(type)
}

fun typeLabel(type: String): String = when (type) {
    SmsParser.PURCHASE -> "شراء"
    SmsParser.WITHDRAWAL -> "سحب نقدي"
    SmsParser.TRANSFER_OUT -> "حوالة صادرة"
    SmsParser.TRANSFER_IN -> "حوالة واردة"
    SmsParser.DEPOSIT -> "إيداع"
    else -> type
}

/** قاعدة البيانات المحلية — كل البيانات تبقى على جوال المستخدم فقط */
class TxDb private constructor(ctx: Context) : SQLiteOpenHelper(ctx, "masroofi.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE tx(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                amount REAL NOT NULL,
                currency TEXT NOT NULL,
                amount_sar REAL NOT NULL,
                type TEXT NOT NULL,
                merchant TEXT NOT NULL,
                category TEXT NOT NULL,
                bank TEXT NOT NULL,
                ts INTEGER NOT NULL,
                raw TEXT NOT NULL,
                dedupe TEXT UNIQUE
            )"""
        )
        db.execSQL("CREATE INDEX idx_tx_ts ON tx(ts)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    /** يرجع true إذا انضافت (false إذا كانت مكررة) */
    fun insert(tx: Tx, dedupe: String?): Boolean {
        val cv = ContentValues().apply {
            put("amount", tx.amount)
            put("currency", tx.currency)
            put("amount_sar", tx.amountSar)
            put("type", tx.type)
            put("merchant", tx.merchant)
            put("category", tx.category)
            put("bank", tx.bank)
            put("ts", tx.timestamp)
            put("raw", tx.raw)
            if (dedupe != null) put("dedupe", dedupe)
        }
        return writableDatabase.insertWithOnConflict("tx", null, cv, SQLiteDatabase.CONFLICT_IGNORE) != -1L
    }

    fun all(): List<Tx> {
        val out = ArrayList<Tx>()
        readableDatabase.rawQuery(
            "SELECT id, amount, currency, amount_sar, type, merchant, category, bank, ts, raw FROM tx ORDER BY ts DESC",
            null
        ).use { c ->
            while (c.moveToNext()) {
                out += Tx(
                    id = c.getLong(0), amount = c.getDouble(1), currency = c.getString(2),
                    amountSar = c.getDouble(3), type = c.getString(4), merchant = c.getString(5),
                    category = c.getString(6), bank = c.getString(7), timestamp = c.getLong(8), raw = c.getString(9)
                )
            }
        }
        return out
    }

    fun updateCategory(id: Long, category: String) {
        writableDatabase.execSQL("UPDATE tx SET category = ? WHERE id = ?", arrayOf<Any>(category, id))
    }

    /** يغيّر تصنيف كل عمليات نفس التاجر (عشان يتعلم التطبيق) */
    fun updateCategoryForMerchant(merchant: String, category: String) {
        writableDatabase.execSQL("UPDATE tx SET category = ? WHERE merchant = ?", arrayOf<Any>(category, merchant))
    }

    fun delete(id: Long) {
        writableDatabase.execSQL("DELETE FROM tx WHERE id = ?", arrayOf<Any>(id))
    }

    fun clear() {
        writableDatabase.execSQL("DELETE FROM tx")
    }

    companion object {
        @Volatile private var instance: TxDb? = null
        fun get(ctx: Context): TxDb = instance ?: synchronized(this) {
            instance ?: TxDb(ctx.applicationContext).also { instance = it }
        }
    }
}

/** تصنيفات يحددها المستخدم لتاجر معيّن */
object MerchantRules {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("merchant_rules", Context.MODE_PRIVATE)
    fun get(ctx: Context, merchant: String): String? = prefs(ctx).getString(merchant.uppercase(Locale.ROOT), null)
    fun set(ctx: Context, merchant: String, category: String) {
        prefs(ctx).edit().putString(merchant.uppercase(Locale.ROOT), category).apply()
    }
}

object TxStore {
    /** يُستدعى لما تتغير البيانات عشان تتحدث الشاشة */
    @Volatile var onChange: (() -> Unit)? = null

    private const val CHANNEL = "tx"

    fun hasSmsPermission(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED

    /** يحلل رسالة ويحفظها. يرجع العملية إذا انحفظت. */
    fun handleSms(ctx: Context, sender: String, body: String, timestamp: Long): Tx? {
        val r = SmsParser.parse(sender, body) ?: return null
        val category = MerchantRules.get(ctx, r.merchant) ?: r.category
        val tx = Tx(
            amount = r.amount, currency = r.currency, amountSar = r.amountSar, type = r.type,
            merchant = r.merchant, category = category, bank = r.bank, timestamp = timestamp, raw = body
        )
        val dedupe = sender.trim() + "|" + body.trim()
        return if (TxDb.get(ctx).insert(tx, dedupe)) tx else null
    }

    fun addManual(ctx: Context, amount: Double, merchant: String, category: String, income: Boolean) {
        val tx = Tx(
            amount = amount, amountSar = amount,
            type = if (income) SmsParser.DEPOSIT else SmsParser.PURCHASE,
            merchant = merchant.ifBlank { if (income) "دخل" else "مصروف يدوي" },
            category = category, bank = "يدوي", timestamp = System.currentTimeMillis(), raw = ""
        )
        TxDb.get(ctx).insert(tx, null)
    }

    /** يقرأ رسائل البنك القديمة من صندوق الوارد. يرجع عدد العمليات الجديدة. */
    fun importInbox(ctx: Context, onProgress: (Int, Int) -> Unit = { _, _ -> }): Int {
        if (!hasSmsPermission(ctx)) return 0
        var added = 0
        val cursor = ctx.contentResolver.query(
            Telephony.Sms.Inbox.CONTENT_URI,
            arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE),
            null, null, Telephony.Sms.DEFAULT_SORT_ORDER
        ) ?: return 0
        cursor.use { c ->
            val total = c.count
            var i = 0
            while (c.moveToNext()) {
                val sender = c.getString(0) ?: ""
                val body = c.getString(1) ?: ""
                val date = c.getLong(2)
                if (handleSms(ctx, sender, body, date) != null) added++
                i++
                if (i % 50 == 0) onProgress(i, total)
            }
            onProgress(total, total)
        }
        return added
    }

    fun notifyNew(ctx: Context, tx: Tx) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "العمليات الجديدة", NotificationManager.IMPORTANCE_DEFAULT))
        val sign = if (tx.isIncome) "+" else "-"
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_agenda)
            .setContentTitle("${typeLabel(tx.type)}: $sign${formatMoney(tx.amountSar)}")
            .setContentText("${tx.merchant} • ${tx.category}")
            .setAutoCancel(true)
            .setContentIntent(
                android.app.PendingIntent.getActivity(
                    ctx, 0,
                    android.content.Intent(ctx, MainActivity::class.java),
                    android.app.PendingIntent.FLAG_IMMUTABLE
                )
            )
            .build()
        nm.notify(tx.timestamp.toInt(), n)
    }

    /** يصدّر كل العمليات لملف CSV يفتح في إكسل */
    fun exportCsv(ctx: Context): File {
        val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, "masroofi.csv")
        val df = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
        fun esc(s: String) = "\"" + s.replace("\"", "\"\"").replace("\n", " ") + "\""
        val sb = StringBuilder("﻿")
        sb.append("التاريخ,النوع,المبلغ,العملة,المبلغ بالريال,التاجر,التصنيف,البنك\n")
        for (t in TxDb.get(ctx).all()) {
            sb.append(df.format(Date(t.timestamp))).append(',')
                .append(esc(typeLabel(t.type))).append(',')
                .append(String.format(Locale.US, "%.2f", t.amount)).append(',')
                .append(t.currency).append(',')
                .append(String.format(Locale.US, "%.2f", if (t.isIncome) t.amountSar else -t.amountSar)).append(',')
                .append(esc(t.merchant)).append(',')
                .append(esc(t.category)).append(',')
                .append(esc(t.bank)).append('\n')
        }
        file.writeText(sb.toString(), Charsets.UTF_8)
        return file
    }
}

fun formatMoney(v: Double): String = String.format(Locale.US, "%,.2f", v) + " ر.س"
